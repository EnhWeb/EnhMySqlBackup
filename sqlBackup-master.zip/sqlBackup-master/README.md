# sqlBackup
A simple mySql backup app with ftp upload support
